module.exports.datastores = {
  mysqlConn: {
    adapter: require('sails-mysql'),
    url: 'mysql://admin:1234prabh@sailscloud.c29kyczbmkqk.us-east-1.rds.amazonaws.com:3306/pkaur'
  }
};